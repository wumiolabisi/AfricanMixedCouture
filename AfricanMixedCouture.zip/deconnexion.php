<?php 

  setcookie('utilisateur', NULL, -1);

  setcookie('idUtilisateur', NULL, -1);
  
  $i = 0;
  while($i!=1){
  
header('Location:index.php');
  $i++;
  
  }

?>