function showCO(){
//tester quelles div est en show
var varDivAccueil = $("#accueil").is(':visible');
var varDivTops = $("#tops").is(':visible');
var varDivCombi = $("#combishort").is(':visible');
var varDivRobes = $("#robes").is(':visible');
var varDivAF = $("#accessoiresf").is(':visible');
var varDivAH = $("#accessoiresh").is(':visible');
var varDivEvent = $("#event").is(':visible');
var varDivServices = $("#services").is(':visible');

if(varDivAccueil == true){
$("#accueil").fadeOut('slow');
$("#CO").fadeIn('slow');
}
else if(varDivTops == true){
$("#tops").fadeOut('slow');
$("#CO").fadeIn('slow');
}
else if(varDivCombi == true){
$("#combishort").fadeOut('slow');
$("#CO").fadeIn('slow');
}
else if(varDivRobes == true){
$("#robes").fadeOut('slow');
$("#CO").fadeIn('slow');
}
else if(varDivAF == true){
$("#accessoiresf").fadeOut('slow');
$("#CO").fadeIn('slow');
}
else if(varDivAH == true){
$("#accessoiresh").fadeOut('slow');
$("#CO").fadeIn('slow');
}
else if(varDivEvent == true){
$("#event").fadeOut('slow');
$("#CO").fadeIn('slow');
}
else if(varDivServices == true){
$("#services").fadeOut('slow');
$("#CO").fadeIn('slow');
}

}

function showTops(){
//tester quelles div est en show
var varDivAccueil = $("#accueil").is(':visible');
var varDivCO = $("#CO").is(':visible');
var varDivCombi = $("#combishort").is(':visible');
var varDivRobes = $("#robes").is(':visible');
var varDivAF = $("#accessoiresf").is(':visible');
var varDivAH = $("#accessoiresh").is(':visible');
var varDivEvent = $("#event").is(':visible');
var varDivServices = $("#services").is(':visible');

if(varDivAccueil == true){
$("#accueil").fadeOut('slow');
$("#tops").fadeIn('slow');
}
else if(varDivCO == true){
$("#CO").fadeOut('slow');
$("#tops").fadeIn('slow');
}
else if(varDivCombi == true){
$("#combishort").fadeOut('slow');
$("#tops").fadeIn('slow');
}
else if(varDivRobes == true){
$("#robes").fadeOut('slow');
$("#tops").fadeIn('slow');
}
else if(varDivAF == true){
$("#accessoiresf").fadeOut('slow');
$("#tops").fadeIn('slow');
}
else if(varDivAH == true){
$("#accessoiresh").fadeOut('slow');
$("#tops").fadeIn('slow');
}
else if(varDivEvent == true){
$("#event").fadeOut('slow');
$("#tops").fadeIn('slow');
}
else if(varDivServices == true){
$("#services").fadeOut('slow');
$("#tops").fadeIn('slow');
}

}

function showCombi(){
//tester quelles div est en show
var varDivAccueil = $("#accueil").is(':visible');
var varDivTops = $("#tops").is(':visible');
var varDivCO = $("#CO").is(':visible');
var varDivRobes = $("#robes").is(':visible');
var varDivAF = $("#accessoiresf").is(':visible');
var varDivAH = $("#accessoiresh").is(':visible');
var varDivEvent = $("#event").is(':visible');
var varDivServices = $("#services").is(':visible');

if(varDivAccueil == true){
$("#accueil").fadeOut('slow');
$("#combishort").fadeIn('slow');
}
else if(varDivTops == true){
$("#tops").fadeOut('slow');
$("#combishort").fadeIn('slow');
}
else if(varDivCO == true){
$("#CO").fadeOut('slow');
$("#combishort").fadeIn('slow');
}
else if(varDivRobes == true){
$("#robes").fadeOut('slow');
$("#combishort").fadeIn('slow');
}
else if(varDivAF == true){
$("#accessoiresf").fadeOut('slow');
$("#combishort").fadeIn('slow');
}
else if(varDivAH == true){
$("#accessoiresh").fadeOut('slow');
$("#combishort").fadeIn('slow');
}
else if(varDivEvent == true){
$("#event").fadeOut('slow');
$("#combishort").fadeIn('slow');
}
else if(varDivServices == true){
$("#services").fadeOut('slow');
$("#combishort").fadeIn('slow');
}

}


function showRobes(){
//tester quelles div est en show
var varDivAccueil = $("#accueil").is(':visible');
var varDivTops = $("#tops").is(':visible');
var varDivCombi = $("#combishort").is(':visible');
var varDivCO = $("#CO").is(':visible');
var varDivAF = $("#accessoiresf").is(':visible');
var varDivAH = $("#accessoiresh").is(':visible');
var varDivEvent = $("#event").is(':visible');
var varDivServices = $("#services").is(':visible');

if(varDivAccueil == true){
$("#accueil").fadeOut('slow');
$("#robes").fadeIn('slow');
}
else if(varDivTops == true){
$("#tops").fadeOut('slow');
$("#robes").fadeIn('slow');
}
else if(varDivCombi == true){
$("#combishort").fadeOut('slow');
$("#robes").fadeIn('slow');
}
else if(varDivCO == true){
$("#CO").fadeOut('slow');
$("#robes").fadeIn('slow');
}
else if(varDivAF == true){
$("#accessoiresf").fadeOut('slow');
$("#robes").fadeIn('slow');
}
else if(varDivAH == true){
$("#accessoiresh").fadeOut('slow');
$("#robes").fadeIn('slow');
}
else if(varDivEvent == true){
$("#event").fadeOut('slow');
$("#robes").fadeIn('slow');
}
else if(varDivServices == true){
$("#services").fadeOut('slow');
$("#robes").fadeIn('slow');
}

}

function showAF(){
//tester quelles div est en show
var varDivAccueil = $("#accueil").is(':visible');
var varDivTops = $("#tops").is(':visible');
var varDivCombi = $("#combishort").is(':visible');
var varDivRobes = $("#robes").is(':visible');
var varDivCO = $("#CO").is(':visible');
var varDivAH = $("#accessoiresh").is(':visible');
var varDivEvent = $("#event").is(':visible');
var varDivServices = $("#services").is(':visible');

if(varDivAccueil == true){
$("#accueil").fadeOut('slow');
$("#accessoiresf").fadeIn('slow');
}
else if(varDivTops == true){
$("#tops").fadeOut('slow');
$("#accessoiresf").fadeIn('slow');
}
else if(varDivCombi == true){
$("#combishort").fadeOut('slow');
$("#accessoiresf").fadeIn('slow');
}
else if(varDivRobes == true){
$("#robes").fadeOut('slow');
$("#accessoiresf").fadeIn('slow');
}
else if(varDivCO == true){
$("#CO").fadeOut('slow');
$("#accessoiresf").fadeIn('slow');
}
else if(varDivAH == true){
$("#accessoiresh").fadeOut('slow');
$("#accessoiresf").fadeIn('slow');
}
else if(varDivEvent == true){
$("#event").fadeOut('slow');
$("#accessoiresf").fadeIn('slow');
}
else if(varDivServices == true){
$("#services").fadeOut('slow');
$("#accessoiresf").fadeIn('slow');
}

}

function showAH(){
//tester quelles div est en show
var varDivAccueil = $("#accueil").is(':visible');
var varDivTops = $("#tops").is(':visible');
var varDivCombi = $("#combishort").is(':visible');
var varDivRobes = $("#robes").is(':visible');
var varDivAF = $("#accessoiresf").is(':visible');
var varDivCO = $("#CO").is(':visible');
var varDivEvent = $("#event").is(':visible');
var varDivServices = $("#services").is(':visible');

if(varDivAccueil == true){
$("#accueil").fadeOut('slow');
$("#accessoiresh").fadeIn('slow');
}
else if(varDivTops == true){
$("#tops").fadeOut('slow');
$("#accessoiresh").fadeIn('slow');
}
else if(varDivCombi == true){
$("#combishort").fadeOut('slow');
$("#accessoiresh").fadeIn('slow');
}
else if(varDivRobes == true){
$("#robes").fadeOut('slow');
$("#accessoiresh").fadeIn('slow');
}
else if(varDivAF == true){
$("#accessoiresf").fadeOut('slow');
$("#accessoiresh").fadeIn('slow');
}
else if(varDivCO == true){
$("#CO").fadeOut('slow');
$("#accessoiresh").fadeIn('slow');
}
else if(varDivEvent == true){
$("#event").fadeOut('slow');
$("#accessoiresh").fadeIn('slow');
}
else if(varDivServices == true){
$("#services").fadeOut('slow');
$("#accessoiresh").fadeIn('slow');
}

}


function showServices(){
//tester quelles div est en show
var varDivAccueil = $("#accueil").is(':visible');
var varDivTops = $("#tops").is(':visible');
var varDivCombi = $("#combishort").is(':visible');
var varDivRobes = $("#robes").is(':visible');
var varDivAF = $("#accessoiresf").is(':visible');
var varDivCO = $("#CO").is(':visible');
var varDivEvent = $("#event").is(':visible');
var varDivAH = $("#accessoiresh").is(':visible');

if(varDivAccueil == true){
$("#accueil").fadeOut('slow');
$("#services").fadeIn('slow');
}
else if(varDivTops == true){
$("#tops").fadeOut('slow');
$("#services").fadeIn('slow');
}
else if(varDivCombi == true){
$("#combishort").fadeOut('slow');
$("#services").fadeIn('slow');
}
else if(varDivRobes == true){
$("#robes").fadeOut('slow');
$("#services").fadeIn('slow');
}
else if(varDivAF == true){
$("#accessoiresf").fadeOut('slow');
$("#services").fadeIn('slow');
}
else if(varDivCO == true){
$("#CO").fadeOut('slow');
$("#services").fadeIn('slow');
}
else if(varDivEvent == true){
$("#event").fadeOut('slow');
$("#services").fadeIn('slow');
}
else if(varDivAH == true){
$("#accessoiresh").fadeOut('slow');
$("#services").fadeIn('slow');
}

}


function showEvent(){
//tester quelles div est en show
var varDivAccueil = $("#accueil").is(':visible');
var varDivTops = $("#tops").is(':visible');
var varDivCombi = $("#combishort").is(':visible');
var varDivRobes = $("#robes").is(':visible');
var varDivAF = $("#accessoiresf").is(':visible');
var varDivCO = $("#CO").is(':visible');
var varDivServices = $("#services").is(':visible');
var varDivAH = $("#accessoiresh").is(':visible');

if(varDivAccueil == true){
$("#accueil").fadeOut('slow');
$("#event").fadeIn('slow');
}
else if(varDivTops == true){
$("#tops").fadeOut('slow');
$("#event").fadeIn('slow');
}
else if(varDivCombi == true){
$("#combishort").fadeOut('slow');
$("#event").fadeIn('slow');
}
else if(varDivRobes == true){
$("#robes").fadeOut('slow');
$("#event").fadeIn('slow');
}
else if(varDivAF == true){
$("#accessoiresf").fadeOut('slow');
$("#event").fadeIn('slow');
}
else if(varDivCO == true){
$("#CO").fadeOut('slow');
$("#event").fadeIn('slow');
}
else if(varDivServices == true){
$("#services").fadeOut('slow');
$("#event").fadeIn('slow');
}
else if(varDivAH == true){
$("#accessoiresh").fadeOut('slow');
$("#event").fadeIn('slow');
}

}


var photoCSV;
 
$(document).ready(function()
  {
      $("#CO").hide();
     $("#tops").hide();
     $("#combishort").hide();
     $("#robes").hide();
     $("#accessoiresf").hide();
     $("#accessoiresh").hide();
	 $("#event").hide();
	 $("#services").hide();
	 $("#accueil").fadeIn('slow');
	 


	 
  });
  
